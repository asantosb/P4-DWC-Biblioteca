export interface Libro {
    id: number;
    titulo: string;
    autor: string;
    descripcion: string;
}
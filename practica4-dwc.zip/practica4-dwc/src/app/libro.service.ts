import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Libro } from './libro';
import { LIBROS } from './libros-json';

@Injectable({
    providedIn: 'root'
})

export class LibroService {
    
    constructor() { }

    getLibros(): Observable<Libro[]> {
        return of(LIBROS);
    }
}

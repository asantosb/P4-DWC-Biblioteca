import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LibrosComponent } from './libros/libros.component';
import { AnadirLibroComponent } from './anadir-libro/anadir-libro.component';

const routes: Routes = [
  { path: 'libros', component: LibrosComponent },
  { path: 'anadir-libro', component: AnadirLibroComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

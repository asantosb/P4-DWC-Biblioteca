import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'; // <-- NgModel lives here

import { AppComponent } from './app.component';
import { LibrosComponent } from './libros/libros.component';
import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from '@angular/router';
import { MessagesComponent } from './messages/messages.component';
import { AnadirLibroComponent } from './anadir-libro/anadir-libro.component';


@NgModule({
  declarations: [
    AppComponent,
    LibrosComponent,
    MessagesComponent,
    AnadirLibroComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';
import { Libro } from '../libro';
import { LibroService } from '../libro.service';
import { MessageService } from '../message.service';

@Component({
  selector: 'app-anadir-libro',
  templateUrl: './anadir-libro.component.html',
  styleUrls: ['./anadir-libro.component.css']
})
export class AnadirLibroComponent implements OnInit {

  libros: Libro[] = [];

  anadirLibro: Libro = {
    id: 0,
    titulo: "",
    autor: "",
    descripcion: ""
  };

  constructor(private libroService: LibroService, private messageService: MessageService) { }

  ngOnInit(): void {
    this.getLibros();
    let ultimoIndice = this.libros.length - 1;
    if(ultimoIndice<0){
      this.anadirLibro.id = 1;
    } else {
      let nuevoId = this.libros[ultimoIndice].id + 1;
      this.anadirLibro.id = nuevoId;
    }
  }

  agregarLibro(){
    let valorId = document.getElementById('valorId');
    let valorTitulo = document.getElementById('valorTitulo');
    let valorAutor = document.getElementById('valorAutor');
    let valorDescripcion = document.getElementById('valorDescripcion');

    if(valorTitulo==null||valorAutor==null){
      this.messageService.add("Rellena el título y el autor.");
      this.messageService.setType("danger");
    } else {
      this.anadirLibro.id++;
      
      let libroNuevo = {
        id: 0,
        titulo: "",
        autor: "",
        descripcion: ""
      }

      libroNuevo.id = Number(valorId.innerText);
      libroNuevo.titulo = valorTitulo.innerText;
      libroNuevo.autor = valorAutor.innerText;
      
      let descripcion = "";
      if(valorDescripcion!=null){
        descripcion = valorDescripcion.innerText;
      }
      libroNuevo.descripcion = descripcion;
      
      this.libroService.sendLibro(libroNuevo);
      this.messageService.add(`El libro '${valorTitulo.innerText}' ha sido añadido correctamente.`);
      this.messageService.setType("success");

      this.anadirLibro.titulo = "";
      this.anadirLibro.autor = "";
      this.anadirLibro.descripcion = "";
    }
  }

  getLibros(): void{
    this.libroService.getLibros()
        .subscribe(libros => this.libros = libros);
  }
}
